﻿/// <autosync enabled="true" />
/// <reference path="../gulpfile.js" />
/// <reference path="lib/jquery/jquery.js" />
/// <reference path="lib/jquery/jquery-migrate.js" />
/// <reference path="lib/hammer.js/hammer.js" />
/// <reference path="lib/bootstrap/js/bootstrap.js" />
